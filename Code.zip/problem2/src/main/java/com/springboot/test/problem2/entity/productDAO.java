package com.springboot.test.problem2.entity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class productDAO {
	List<product> productList=new ArrayList<>();
	
public List<product> saveProduct(product product){
		productList.add(product);
		return productList.stream().sorted(Comparator.comparing(x->x.productId)).
				sorted(Comparator.comparing(x->x.launchDate)).collect(Collectors.toList());
	}
}
