package com.springboot.test.problem2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.test.problem2.entity.product;
import com.springboot.test.problem2.entity.productDAO;

@RestController
public class myController {
	
	@Autowired
	private productDAO productService;
	
	@PostMapping("/createProduct")
	public List<product> postUser(@RequestBody product prod){
		return productService.saveProduct(prod);
	}
}
