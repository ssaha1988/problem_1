package com.springboot.test.problem1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.test.problem1.controller.entity.productDAO;
import com.springboot.test.problem1.controller.entity.productEntity;

@RestController
public class myController {

	@Autowired
	private productDAO productService;
	
	@GetMapping("/getProduct")
	public List<productEntity> getAllProd(){
		return productService.findAll();
	}
	
	@PostMapping("/createProduct")
	public productEntity postUser(@RequestBody productEntity prod){
		return productService.saveProduct(prod);
	}
}
