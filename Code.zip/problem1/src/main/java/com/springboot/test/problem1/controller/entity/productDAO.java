package com.springboot.test.problem1.controller.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class productDAO {
	private static List<productEntity> products=new ArrayList<>();
	static {
		products.add(new productEntity("Prod1","Shirt","EACH",""));
		products.add(new productEntity("Prod2","Trousers","EACH",""));
		products.add(new productEntity("Prod3","Tie","EACH",""));
	}
	
	
	public List<productEntity> findAll() {
		return products;
	}
	
	public productEntity saveProduct(productEntity product){
		
		for(productEntity prod:products){
			if(prod.getProdNum()==product.getProdNum() && 
					prod.getProdDesc()==product.getProdDesc() && 
					prod.getProdUOM()==product.getProdUOM()){
				product.setStatus("Exists");
				
			}
				
			else {
				product.setStatus("Created");
				products.add(product);
				
			}
				
		}
		return product;
		
	}
}