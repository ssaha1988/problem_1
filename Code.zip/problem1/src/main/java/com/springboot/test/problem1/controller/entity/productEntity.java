package com.springboot.test.problem1.controller.entity;

public class productEntity {
	private String prodNum;
	private String prodDesc;
	private String prodUOM;
	private String Status;
	
	
	public String getProdNum() {
		return prodNum;
	}
	public void setProdNum(String prodNum) {
		this.prodNum = prodNum;
	}
	public String getProdDesc() {
		return prodDesc;
	}
	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}
	public String getProdUOM() {
		return prodUOM;
	}
	public void setProdUOM(String prodUOM) {
		this.prodUOM = prodUOM;
	}
	
	
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public productEntity(String prodNum, String prodDesc, String prodUOM, String Status) {
		super();
		this.prodNum = prodNum;
		this.prodDesc = prodDesc;
		this.prodUOM = prodUOM;
		this.Status = Status;
	}
	protected productEntity() {
		
	}
	
	
	
}
